import SignUp from "./signup/SignUp"
import Header from "./Navbar"
function SignupPage(){
    return (
        <>
            <Header/>
            <SignUp/>
        </>
    );
}

export default SignupPage;